import './Body.css';

function BodyContentComponent(props) {
   
    return(
        <div className="BodyContent">
            {/* Print the prop content below */}
           <h3>{props.content}</h3>
        </div>
    );
}

export default BodyContentComponent;