function LogoComponent() {
    return(
        <div className="LogoComponent">
            <h4>I am a Logo Component !!!</h4>
        </div>
    );
}

export default LogoComponent;